from os import system as s
s('python -m http.server 80')